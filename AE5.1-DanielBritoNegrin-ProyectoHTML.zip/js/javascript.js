function pintura() {
    alert('Esta sección no está habilitada!!!')
}